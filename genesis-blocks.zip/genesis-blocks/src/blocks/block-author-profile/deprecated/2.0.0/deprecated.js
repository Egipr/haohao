import attributes from './attributes';
import migrate from './utils/migrate';
import save from './components/save';

export default {
	attributes,
	migrate,
	save,
}
