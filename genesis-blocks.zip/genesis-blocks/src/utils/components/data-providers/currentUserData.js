export default function getCurrentUserData() {
	return genesis_blocks_globals.user_data;
}
