<?php
/**
 * Block Serialization Parser
 *
 * @package WordPress
 */

// Require files.
require_once __DIR__ . '/class-wp-block-parser-block.php';
require_once __DIR__ . '/class-wp-block-parser-frame.php';
require_once __DIR__ . '/class-wp-block-parser.php';
