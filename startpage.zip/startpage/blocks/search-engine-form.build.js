/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var __ = wp.i18n.__;
var registerBlockType = wp.blocks.registerBlockType;
var Fragment = wp.element.Fragment;
var InspectorControls = wp.editor.InspectorControls;
var _wp$components = wp.components,
    PanelBody = _wp$components.PanelBody,
    CheckboxControl = _wp$components.CheckboxControl,
    SelectControl = _wp$components.SelectControl;

var classNames = __webpack_require__(1);

function get_search_form_attributes(attributes) {
	var htmlAttributes = {
		form: {},
		input: {
			name: 'q',
			autocomplete: 'off',
			autofocus: attributes.autofocus || false
		},
		button: {}
	};

	switch (attributes.searchengine) {
		default:
		case 'duckduckgo':
			htmlAttributes.form.action = 'https://duckduckgo.com/';
			htmlAttributes.input.placeholder = 'Duckduckgo...';
			break;
		case 'google':
			htmlAttributes.form.action = 'https://google.com/';
			htmlAttributes.input.placeholder = 'Google...';
			break;
		case 'wikipedia':
			htmlAttributes.form.action = 'https://de.wikipedia.org/wiki/Special:Search';
			htmlAttributes.input.placeholder = 'Wikipedia...';
			htmlAttributes.input.name = 'search';
			break;
		case 'yahoo':
			htmlAttributes.form.action = 'https://search.yahoo.com/';
			htmlAttributes.input.placeholder = 'Yahoo...';
			htmlAttributes.input.name = 'p';
			break;
		case 'bing':
			htmlAttributes.form.action = 'https://bing.com/';
			htmlAttributes.input.placeholder = 'Bing...';
			break;
	}

	return htmlAttributes;
}

function get_search_form(htmlAttributes, className) {
	return wp.element.createElement(
		'form',
		_extends({ className: classNames(className, 'search-form') }, htmlAttributes.form),
		wp.element.createElement('input', _extends({ className: 'search-field' }, htmlAttributes.input)),
		wp.element.createElement(
			'button',
			_extends({ className: 'search-submit' }, htmlAttributes.button),
			__('Search', 'startpage')
		)
	);
}

registerBlockType('startpage/search-engine-form', {
	title: 'Search Engine Form',
	icon: 'search',
	category: 'layout',
	attributes: {
		searchengine: {
			type: 'string'
		},
		autofocus: {
			type: 'boolean',
			default: false
		}
	},

	edit: function edit(_ref) {
		var attributes = _ref.attributes,
		    setAttributes = _ref.setAttributes,
		    className = _ref.className;

		var inspector = wp.element.createElement(
			InspectorControls,
			null,
			wp.element.createElement(
				PanelBody,
				null,
				wp.element.createElement(SelectControl, {
					label: __('Search Engine', 'startpage'),
					onChange: function onChange(searchengine) {
						return setAttributes({ searchengine: searchengine });
					},
					value: attributes.searchengine,
					options: [{
						label: 'DuckDuckGo',
						value: 'duckduckgo'
					}, {
						label: 'Google',
						value: 'google'
					}, {
						label: 'Wikipedia',
						value: 'wikipedia'
					}, {
						label: 'Bing',
						value: 'bing'
					}, {
						label: 'Yahoo',
						value: 'yahoo'
					}]
				}),
				wp.element.createElement(CheckboxControl, {
					label: __('Autofocus', 'startpage'),
					checked: attributes.autofocus,
					onChange: function onChange(autofocus) {
						return setAttributes({ autofocus: autofocus });
					}
				})
			)
		);

		var htmlAttributes = get_search_form_attributes(attributes);
		htmlAttributes.input.autofocus = false;
		htmlAttributes.button.disabled = true;

		return wp.element.createElement(
			Fragment,
			null,
			inspector,
			get_search_form(htmlAttributes, className)
		);
	},
	save: function save(_ref2) {
		var attributes = _ref2.attributes,
		    className = _ref2.className;

		return get_search_form(get_search_form_attributes(attributes), className);
	}
});

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2017 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
	'use strict';

	var hasOwn = {}.hasOwnProperty;

	function classNames () {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg) && arg.length) {
				var inner = classNames.apply(null, arg);
				if (inner) {
					classes.push(inner);
				}
			} else if (argType === 'object') {
				for (var key in arg) {
					if (hasOwn.call(arg, key) && arg[key]) {
						classes.push(key);
					}
				}
			}
		}

		return classes.join(' ');
	}

	if (typeof module !== 'undefined' && module.exports) {
		classNames.default = classNames;
		module.exports = classNames;
	} else if (true) {
		// register as 'classnames', consistent with npm package name
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return classNames;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else {
		window.classNames = classNames;
	}
}());


/***/ })
/******/ ]);